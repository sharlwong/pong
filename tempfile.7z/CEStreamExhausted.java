/* Decompiled through IntelliJad */
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(3) packimports(3) splitstr(64) radix(10) lradix(10) 
// Source File Name:   CEStreamExhausted.java

package sun.misc;

import java.io.IOException;

public class CEStreamExhausted extends IOException {

	public CEStreamExhausted() {
	}
}
