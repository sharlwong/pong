package archived.security_lab.mutualAuth;

/**
 * Created by avery_000 on 10-Apr-14.
 */
public class TestClient6Test {
	public static void main(String[] args) throws Exception {
		TestClient6.main(new String[]{"-c","T4"});
	}
}
