package archived.security_lab.mutualAuth;

/**
 * Created by avery_000 on 10-Apr-14.
 */
public class TestServer6Test {
	public static void main(String[] args) throws Exception {
		TestServer6.main(new String[]{"-c","T4"});
	}
}
